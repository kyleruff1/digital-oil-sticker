# Digital Oil Sticker brand assets

The approved canonical main logo is `digital-oil-sticker-logo.svg`. Its 1200×520 transparent PNG render is byte-for-byte identical to the approved `digital-oil-sticker-logo (1).png` reference selected on 2026-07-31.

## Primary assets

- `digital-oil-sticker-logo.svg`: primary service-form company lockup for the static site, help pages, attribution, and release collateral. It includes the permanent `NEXT SERVICE DUE`, `DATE OR MILEAGE`, and `GRADE` fields, two crossed strongly-waving checkered flags on short pole stubs, and a decorative peel corner.
- `digital-oil-sticker-logo.png`: 1200px transparent raster fallback rendered from the primary SVG.
- `digital-oil-sticker-mark.svg`: compact symbol for favicons, launch artwork, and later app-icon production.
- `favicon.svg` and `favicon.ico`: scalable and legacy browser favicons.
- `favicon-16x16.png` and `favicon-32x32.png`: explicit browser PNG fallbacks.
- `apple-touch-icon.png`: 180px Apple home-screen icon.
- `android-chrome-192x192.png` and `android-chrome-512x512.png`: manifest icons.
- `site.webmanifest`: web-icon metadata with the locked brand colors.
- `digital-oil-sticker-logo-concept.png`: superseded teal/amber exploration retained only as design history; do not use it in production.

## Color contract

| Role | Hex |
| --- | --- |
| Service green | `#159447` |
| Digital blue | `#1769AA` |
| Structural black | `#111111` |
| Sticker white | `#FFFFFF` |

Keep clear space equal to at least one large pixel-square width. Do not remove or rewrite the service-field labels, recolor individual elements, add gradients/shadows, or stretch the artwork. Do not place the full sticker lockup below 320 CSS pixels wide; at smaller sizes, use the compact mark.

The SVG canvas is transparent outside the white sticker shape. Before app-store submission, produce platform-specific icon exports with the required opaque backgrounds and safe zones; do not submit this transparent master directly as an iOS app icon.

The main logo's black border is inset from the SVG canvas. At the canonical 1200×520 render, the visible artwork begins 29 pixels inside every edge, leaving a real alpha-transparent margin outside the border and peel corner. Do not crop, fill, or remove this margin in site exports.

## HTML integration

```html
<link rel="icon" href="/assets/brand/favicon.ico" sizes="any">
<link rel="icon" href="/assets/brand/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/assets/brand/apple-touch-icon.png">
<link rel="manifest" href="/assets/brand/site.webmanifest">
<meta name="theme-color" content="#159447">
```
